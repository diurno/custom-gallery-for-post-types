<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class Custom_Gallery_Image_For_Post_Types_Helpers
 *
 * This class contains repetitive functions that
 * are used globally within the plugin.
 *
 * @package		CGPT
 * @subpackage	Classes/Custom_Gallery_Image_For_Post_Types_Helpers
 * @author		federico cadierno
 * @since		1.0.0
 */
class Custom_Gallery_Image_For_Post_Types_Helpers{

	/**
	 * ######################
	 * ###
	 * #### CALLABLE FUNCTIONS
	 * ###
	 * ######################
	 */

}
